package com.example.cricketoons.model.fixtureWithTeam

data class VisitorteamDlData(
    var overs: String?,
    var score: String?,
    var total_overs_played: String?,
    var wickets_out: String?
)