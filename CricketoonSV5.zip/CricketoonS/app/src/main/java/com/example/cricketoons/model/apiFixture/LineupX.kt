package com.example.cricketoons.model.apiFixture

data class LineupX(
    var captain: Boolean,
    var substitution: Boolean,
    var team_id: Int,
    var wicketkeeper: Boolean
)