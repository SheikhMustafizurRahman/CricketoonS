package com.example.cricketoons.model.roomTeams

data class TeamSquad(
    var `data`: List<TeamData>
)