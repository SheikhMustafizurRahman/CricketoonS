package com.example.cricketoons.fragments

class SquadFragment : Fragment() {

}
