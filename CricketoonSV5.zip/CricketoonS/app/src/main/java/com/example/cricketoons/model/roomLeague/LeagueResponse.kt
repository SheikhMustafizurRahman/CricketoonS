package com.example.cricketoons.model.roomLeague

data class LeagueResponse(
    var `data`: List<League>
)