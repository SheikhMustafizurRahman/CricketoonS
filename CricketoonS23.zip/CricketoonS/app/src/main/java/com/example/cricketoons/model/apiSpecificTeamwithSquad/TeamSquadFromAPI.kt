package com.example.cricketoons.model.apiSpecificTeamwithSquad

import com.example.cricketoons.model.roomTeams.TeamData

data class TeamSquadFromAPI(
    var `data`: TeamData
)