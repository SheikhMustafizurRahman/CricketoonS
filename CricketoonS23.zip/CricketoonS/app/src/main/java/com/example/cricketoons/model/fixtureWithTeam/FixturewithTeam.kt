package com.example.cricketoons.model.fixtureWithTeam

data class FixturewithTeam(
    var `data`: List<FixtureDataWteam>,
    var links: Links?,
    var meta: Meta?
)