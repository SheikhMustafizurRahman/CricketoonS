package com.example.cricketoons.model.rankingAPI

data class RankingResponse(
    var `data`: List<RankingData>
)