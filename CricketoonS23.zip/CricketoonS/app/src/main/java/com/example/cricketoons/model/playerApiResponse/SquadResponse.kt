package com.example.cricketoons.model.playerApiResponse

import com.example.cricketoons.model.apiSpecificTeamwithSquad.Squad

data class SquadResponse(
    var `data`: Squad
)