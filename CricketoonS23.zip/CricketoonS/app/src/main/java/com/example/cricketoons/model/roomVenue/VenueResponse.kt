package com.example.cricketoons.model.roomVenue

data class VenueResponse(
    var `data`: List<Venue>
)