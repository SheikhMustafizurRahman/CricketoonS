package com.example.cricketoons.model.apiFixture

data class Link(
    var active: Boolean,
    var label: String,
    var url: String?
)