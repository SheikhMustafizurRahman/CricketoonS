package com.example.cricketoons.model.fixtureWithTeam

data class Links(
    var first: String?,
    var last: String?,
    var next: String?,
    var prev: Any?
)