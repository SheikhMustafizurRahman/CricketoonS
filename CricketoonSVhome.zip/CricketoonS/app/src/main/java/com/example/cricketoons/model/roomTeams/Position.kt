package com.example.cricketoons.model.roomTeams

data class Position(
    var id: Int?,
    var name: String?,
    var resource: String?
)