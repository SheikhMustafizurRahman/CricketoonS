package com.example.cricketoons.model.fixtureWithTeam

data class Link(
    var active: Boolean?,
    var label: String?,
    var url: String?
)