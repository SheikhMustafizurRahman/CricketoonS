package com.example.cricketoons.model.playerApiResponse

data class Position(
    var id: Int,
    var name: String,
    var resource: String
)