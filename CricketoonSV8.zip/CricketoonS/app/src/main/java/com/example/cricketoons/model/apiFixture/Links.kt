package com.example.cricketoons.model.apiFixture

data class Links(
    var first: String?,
    var last: String?,
    var next: Any?,
    var prev: Any?
)