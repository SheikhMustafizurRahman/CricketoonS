package com.example.cricketoons.model.roomCountry

data class CountryResponse(
    var `data`: List<Country>
)