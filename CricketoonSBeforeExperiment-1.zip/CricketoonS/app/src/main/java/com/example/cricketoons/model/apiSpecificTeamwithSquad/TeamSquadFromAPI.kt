package com.example.cricketoons.model.apiSpecificTeamwithSquad

data class TeamSquadFromAPI(
    var `data`: TeamDataFromAPI
)