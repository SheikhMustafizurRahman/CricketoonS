package com.example.cricketoons.model.roomSeason

data class SeasonResponse(
    var `data`: List<Season>
)