package com.example.cricketoons.model.rankingAPI

data class Ranking(
    var matches: Int,
    var points: Int,
    var position: Int,
    var rating: Int
)