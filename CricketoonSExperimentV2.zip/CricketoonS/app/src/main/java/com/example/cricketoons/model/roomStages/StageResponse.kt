package com.example.cricketoons.model.roomStages

data class StageResponse(
    var `data`: List<Stages>
)