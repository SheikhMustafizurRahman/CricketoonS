package com.example.cricketoons.model.roomTeams

data class SquadX(
    var season_id: Int?
)