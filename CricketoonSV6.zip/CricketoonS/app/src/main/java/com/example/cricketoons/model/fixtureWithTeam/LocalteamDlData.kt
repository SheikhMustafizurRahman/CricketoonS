package com.example.cricketoons.model.fixtureWithTeam

data class LocalteamDlData(
    var overs: String?,
    var rpc_overs: String?,
    var rpc_targets: String?,
    var score: String?,
    var wickets_out: String?
)