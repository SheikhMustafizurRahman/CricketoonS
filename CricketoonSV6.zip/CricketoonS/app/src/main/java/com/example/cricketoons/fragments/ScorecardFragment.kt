package com.example.cricketoons.fragments

import androidx.fragment.app.Fragment
import com.example.cricketoons.model.apiFixture.Fixture

class ScorecardFragment(fixture: Fixture) : Fragment() {

}
