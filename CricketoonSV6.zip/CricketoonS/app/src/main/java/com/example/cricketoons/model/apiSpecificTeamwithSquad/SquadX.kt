package com.example.cricketoons.model.apiSpecificTeamwithSquad

data class SquadX(
    var season_id: Int?
)