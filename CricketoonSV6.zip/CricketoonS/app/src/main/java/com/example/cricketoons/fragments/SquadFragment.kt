package com.example.cricketoons.fragments

import androidx.fragment.app.Fragment
import com.example.cricketoons.model.apiFixture.Fixture

class SquadFragment(fixture: Fixture) : Fragment() {

}
